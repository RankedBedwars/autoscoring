#!/bin/bash
. /root/.nvm/nvm.sh
npm start
